USE [CSDL_ass2]
GO

/****** Object:  Table [dbo].[Bang_gia]    Script Date: 6/5/2021 8:20:31 PM ******/
DROP TABLE [dbo].[Bang_gia]
GO

/****** Object:  Table [dbo].[Bang_gia]    Script Date: 6/5/2021 8:20:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Bang_gia](
	[Don_gia_xe_buyt] [money] NULL,
	[Gia_ve_trong_tuan] [money] NULL,
	[Gia_ve_cuoi_tuan] [money] NULL
) ON [PRIMARY]

GO


