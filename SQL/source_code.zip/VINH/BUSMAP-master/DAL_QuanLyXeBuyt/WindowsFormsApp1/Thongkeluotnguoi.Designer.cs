﻿namespace WindowsFormsApp1
{
    partial class Thongkeluotnguoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.banghanhkhach = new System.Windows.Forms.DataGridView();
            this.btn_thongkeluothanhkhach_close = new System.Windows.Forms.Button();
            this.lb_matuyen = new System.Windows.Forms.Label();
            this.txt_matuyen = new System.Windows.Forms.TextBox();
            this.txt_tungay = new System.Windows.Forms.TextBox();
            this.lb_tungay = new System.Windows.Forms.Label();
            this.txt_toingay = new System.Windows.Forms.TextBox();
            this.lb_denngay = new System.Windows.Forms.Label();
            this.lb_tracuu = new System.Windows.Forms.Label();
            this.btn_tracuu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.banghanhkhach)).BeginInit();
            this.SuspendLayout();
            // 
            // banghanhkhach
            // 
            this.banghanhkhach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.banghanhkhach.Location = new System.Drawing.Point(239, 12);
            this.banghanhkhach.Name = "banghanhkhach";
            this.banghanhkhach.Size = new System.Drawing.Size(244, 201);
            this.banghanhkhach.TabIndex = 12;
            // 
            // btn_thongkeluothanhkhach_close
            // 
            this.btn_thongkeluothanhkhach_close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_thongkeluothanhkhach_close.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_thongkeluothanhkhach_close.Location = new System.Drawing.Point(126, 181);
            this.btn_thongkeluothanhkhach_close.Name = "btn_thongkeluothanhkhach_close";
            this.btn_thongkeluothanhkhach_close.Size = new System.Drawing.Size(98, 32);
            this.btn_thongkeluothanhkhach_close.TabIndex = 11;
            this.btn_thongkeluothanhkhach_close.Text = "Thoát";
            this.btn_thongkeluothanhkhach_close.UseVisualStyleBackColor = true;
            this.btn_thongkeluothanhkhach_close.Click += new System.EventHandler(this.btn_thongkeluothanhkhach_close_Click);
            // 
            // lb_matuyen
            // 
            this.lb_matuyen.AutoSize = true;
            this.lb_matuyen.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_matuyen.Location = new System.Drawing.Point(6, 60);
            this.lb_matuyen.Name = "lb_matuyen";
            this.lb_matuyen.Size = new System.Drawing.Size(88, 21);
            this.lb_matuyen.TabIndex = 2;
            this.lb_matuyen.Text = "Mã tuyến :";
            // 
            // txt_matuyen
            // 
            this.txt_matuyen.Location = new System.Drawing.Point(99, 59);
            this.txt_matuyen.Name = "txt_matuyen";
            this.txt_matuyen.Size = new System.Drawing.Size(125, 20);
            this.txt_matuyen.TabIndex = 3;
            this.txt_matuyen.Text = "T001";
            // 
            // txt_tungay
            // 
            this.txt_tungay.Location = new System.Drawing.Point(99, 97);
            this.txt_tungay.Name = "txt_tungay";
            this.txt_tungay.Size = new System.Drawing.Size(125, 20);
            this.txt_tungay.TabIndex = 5;
            this.txt_tungay.Text = "2021-06-16";
            // 
            // lb_tungay
            // 
            this.lb_tungay.AutoSize = true;
            this.lb_tungay.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tungay.Location = new System.Drawing.Point(6, 98);
            this.lb_tungay.Name = "lb_tungay";
            this.lb_tungay.Size = new System.Drawing.Size(81, 21);
            this.lb_tungay.TabIndex = 4;
            this.lb_tungay.Text = "Từ ngày :";
            // 
            // txt_toingay
            // 
            this.txt_toingay.Location = new System.Drawing.Point(99, 133);
            this.txt_toingay.Name = "txt_toingay";
            this.txt_toingay.Size = new System.Drawing.Size(125, 20);
            this.txt_toingay.TabIndex = 7;
            this.txt_toingay.Text = "2021-06-18";
            // 
            // lb_denngay
            // 
            this.lb_denngay.AutoSize = true;
            this.lb_denngay.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_denngay.Location = new System.Drawing.Point(6, 134);
            this.lb_denngay.Name = "lb_denngay";
            this.lb_denngay.Size = new System.Drawing.Size(90, 21);
            this.lb_denngay.TabIndex = 6;
            this.lb_denngay.Text = "Đến ngày :";
            // 
            // lb_tracuu
            // 
            this.lb_tracuu.AutoSize = true;
            this.lb_tracuu.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tracuu.Location = new System.Drawing.Point(12, 12);
            this.lb_tracuu.Name = "lb_tracuu";
            this.lb_tracuu.Size = new System.Drawing.Size(216, 23);
            this.lb_tracuu.TabIndex = 8;
            this.lb_tracuu.Text = "Tra cứu lượt hành khách";
            // 
            // btn_tracuu
            // 
            this.btn_tracuu.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tracuu.Location = new System.Drawing.Point(10, 181);
            this.btn_tracuu.Name = "btn_tracuu";
            this.btn_tracuu.Size = new System.Drawing.Size(110, 32);
            this.btn_tracuu.TabIndex = 9;
            this.btn_tracuu.Text = "Tra cứu";
            this.btn_tracuu.UseVisualStyleBackColor = true;
            this.btn_tracuu.Click += new System.EventHandler(this.btn_tracuu_Click);
            // 
            // Thongkeluotnguoi
            // 
            this.AcceptButton = this.btn_tracuu;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_thongkeluothanhkhach_close;
            this.ClientSize = new System.Drawing.Size(489, 221);
            this.Controls.Add(this.btn_tracuu);
            this.Controls.Add(this.lb_tracuu);
            this.Controls.Add(this.txt_toingay);
            this.Controls.Add(this.lb_denngay);
            this.Controls.Add(this.txt_tungay);
            this.Controls.Add(this.lb_tungay);
            this.Controls.Add(this.txt_matuyen);
            this.Controls.Add(this.lb_matuyen);
            this.Controls.Add(this.btn_thongkeluothanhkhach_close);
            this.Controls.Add(this.banghanhkhach);
            this.Name = "Thongkeluotnguoi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thống kê lượt hành khách";
            ((System.ComponentModel.ISupportInitialize)(this.banghanhkhach)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView banghanhkhach;
        private System.Windows.Forms.Button btn_thongkeluothanhkhach_close;
        private System.Windows.Forms.Label lb_matuyen;
        private System.Windows.Forms.TextBox txt_matuyen;
        private System.Windows.Forms.TextBox txt_tungay;
        private System.Windows.Forms.Label lb_tungay;
        private System.Windows.Forms.TextBox txt_toingay;
        private System.Windows.Forms.Label lb_denngay;
        private System.Windows.Forms.Label lb_tracuu;
        private System.Windows.Forms.Button btn_tracuu;
    }
}