﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL_QuanLyXeBuyt;

namespace WindowsFormsApp1
{
    public partial class Thongkeluotnguoi : Form
    {
        public Thongkeluotnguoi()
        {
            InitializeComponent();
        }

        

        private void btn_thongkeluothanhkhach_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_tracuu_Click(object sender, EventArgs e)
        {
            banghanhkhach.DataSource = Thong_Ke_Luot_Nguoi();
        }

        DataTable Thong_Ke_Luot_Nguoi()
        {
            string MATUYEN = txt_matuyen.Text;
            string TU_NGAY = txt_tungay.Text;
            string TOI_NGAY = txt_toingay.Text;
            return ThongKe_DAL.Instance.Thong_Ke_Luot_Nguoi(MATUYEN, TU_NGAY, TOI_NGAY);
        }


    }
}
