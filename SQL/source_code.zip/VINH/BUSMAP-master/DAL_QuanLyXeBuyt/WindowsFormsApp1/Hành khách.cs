﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL_QuanLyXeBuyt;

namespace WindowsFormsApp1
{
    public partial class Passenger : Form
    {
        public Passenger()
        {
            InitializeComponent();
        }

        private void btn_Hanhkhach_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Passenger_Load(object sender, EventArgs e)
        {
            ViewDanhSach.DataSource = Xem_Hanh_Khach();
        }



        DataTable Xem_Hanh_Khach()
        {
            return Hanh_Khach_DAL.Instance.Xem_Hanh_Khach();
        }

       
    }
}
