﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Themtuyen : Form
    {
        public Themtuyen()
        {
            InitializeComponent();
        }


        SqlConnection con;
       


        private void Themtuyen_Load(object sender, EventArgs e)
        {
            string conString = ConfigurationManager.ConnectionStrings["QLtuyentauxe"].ConnectionString.ToString();
            con = new SqlConnection(conString);
            con.Open();
            Hienthi();
        }

        private void Themtuyen_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Close();

        }



        public void Hienthi() 
        {
            string sqlSELECT = "SELECT *FROM CHUYEN_TAU_GHE_TRAM";
            SqlCommand cmd = new SqlCommand(sqlSELECT, con);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dsSanPham.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlINSET = "INSERT INTO CHUYEN_TAU_GHE_TRAM VALUES (@MA_TUYEN_XE ,@STT ,@MA_GA,@STT_TRAM_DUNG,@GIO_GHE,@GIO_DI)";
            SqlCommand cmd = new SqlCommand(sqlINSET, con);
            cmd.Parameters.AddWithValue("MA_TUYEN_XE", txt_matuyenxe.Text);
            cmd.Parameters.AddWithValue("STT", txt_stt.Text);
            cmd.Parameters.AddWithValue("MA_GA", txt_maga.Text);
            cmd.Parameters.AddWithValue("STT_TRAM_DUNG", txt_stttramdung.Text);
            cmd.Parameters.AddWithValue("GIO_GHE", txt_gioghe.Text);
            cmd.Parameters.AddWithValue("GIO_DI", txt_giodi.Text);
            cmd.ExecuteNonQuery();

            Hienthi();

        }

        
    }
}
