﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL_QuanLyXeBuyt
{
    class ThongKe_DAL
    {
        private static ThongKe_DAL instance;

        public static ThongKe_DAL Instance
        {
            get { if (instance == null) instance = new ThongKe_DAL(); return instance; }
            private set { instance = value; }
        }

        private ThongKe_DAL() { }

        public bool Login(string userName, string passWord)
        {
            string query = "SELECT * FROM dbo.ACCOUNT WHERE USERNAME = N'" + userName + "' AND PASSWORD_ = N'" + passWord + "' ";
            //string query = "SELECT * FROM dbo.NHAN_VIEN ";
            DataTable result = DataProvider.Instance.ExecuteQuery(query);

            return result.Rows.Count > 0;
        }



        public DataTable Thong_Ke_Luot_Nguoi(string MATUYEN, string TU_NGAY, string TOI_NGAY)
        {

            //string query = "EXEC dbo.ThongKeLuotNguoi @MATUYEN @TU_NGAY @TOI_NGAY";
            //string query = "EXEC ThongKeLuotNguoi 'T002','2021-06-16','2021-06-18'";
            string query = "EXEC ThongKeLuotNguoi '" + MATUYEN + "','" + TU_NGAY + "','" + TOI_NGAY + "'";
            //return DataProvider.Instance.ExecuteQuery(query,new object[] { "T001", "2021-06-16" , "2021-06-18" });
            return DataProvider.Instance.ExecuteQuery(query);
        }
    }
}
