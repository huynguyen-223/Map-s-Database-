﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL_QuanLyXeBuyt;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }



     

        DataTable Xem_Hanh_Khach()
        {
            return Hanh_Khach_DAL.Instance.Xem_Hanh_Khach();
        }

       


        private void btn_ThemTuyenTauXe_Click(object sender, EventArgs e)
        {
            Themtuyen f = new Themtuyen();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }
    

        private void btn_hanhkhach_Click(object sender, EventArgs e)
        {
            Passenger f = new Passenger();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }


        private void btn_bangthongke_Click(object sender, EventArgs e)
        {
            Thongkeluotnguoi f = new Thongkeluotnguoi();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }
    }   
}
