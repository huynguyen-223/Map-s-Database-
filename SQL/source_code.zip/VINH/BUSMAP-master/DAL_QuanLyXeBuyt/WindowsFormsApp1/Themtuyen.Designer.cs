﻿namespace WindowsFormsApp1
{
    partial class Themtuyen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_matuyenxe = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_stt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_maga = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_stttramdung = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_gioghe = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_giodi = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.dsSanPham = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dsSanPham)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã tuyến xe";
            // 
            // txt_matuyenxe
            // 
            this.txt_matuyenxe.Location = new System.Drawing.Point(107, 16);
            this.txt_matuyenxe.Name = "txt_matuyenxe";
            this.txt_matuyenxe.Size = new System.Drawing.Size(237, 20);
            this.txt_matuyenxe.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "STT";
            // 
            // txt_stt
            // 
            this.txt_stt.Location = new System.Drawing.Point(107, 42);
            this.txt_stt.Name = "txt_stt";
            this.txt_stt.Size = new System.Drawing.Size(237, 20);
            this.txt_stt.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Mã ga";
            // 
            // txt_maga
            // 
            this.txt_maga.Location = new System.Drawing.Point(107, 68);
            this.txt_maga.Name = "txt_maga";
            this.txt_maga.Size = new System.Drawing.Size(237, 20);
            this.txt_maga.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "STT trạm dừng";
            // 
            // txt_stttramdung
            // 
            this.txt_stttramdung.Location = new System.Drawing.Point(107, 94);
            this.txt_stttramdung.Name = "txt_stttramdung";
            this.txt_stttramdung.Size = new System.Drawing.Size(237, 20);
            this.txt_stttramdung.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Giờ ghé";
            // 
            // txt_gioghe
            // 
            this.txt_gioghe.Location = new System.Drawing.Point(107, 120);
            this.txt_gioghe.Name = "txt_gioghe";
            this.txt_gioghe.Size = new System.Drawing.Size(237, 20);
            this.txt_gioghe.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Giờ đi";
            // 
            // txt_giodi
            // 
            this.txt_giodi.Location = new System.Drawing.Point(107, 146);
            this.txt_giodi.Name = "txt_giodi";
            this.txt_giodi.Size = new System.Drawing.Size(237, 20);
            this.txt_giodi.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(358, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 38);
            this.button1.TabIndex = 2;
            this.button1.Text = "Thêm";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(358, 108);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 38);
            this.button2.TabIndex = 2;
            this.button2.Text = "Xoá ";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(511, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(160, 38);
            this.button3.TabIndex = 2;
            this.button3.Text = "Sửa";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btn_close
            // 
            this.btn_close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_close.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.Location = new System.Drawing.Point(511, 108);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(160, 38);
            this.btn_close.TabIndex = 2;
            this.btn_close.Text = "Thoát";
            this.btn_close.UseVisualStyleBackColor = true;
            // 
            // dsSanPham
            // 
            this.dsSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dsSanPham.Location = new System.Drawing.Point(22, 186);
            this.dsSanPham.Name = "dsSanPham";
            this.dsSanPham.Size = new System.Drawing.Size(649, 438);
            this.dsSanPham.TabIndex = 3;
            // 
            // Themtuyen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_close;
            this.ClientSize = new System.Drawing.Size(683, 656);
            this.Controls.Add(this.dsSanPham);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_giodi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_gioghe);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_stttramdung);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_maga);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_stt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_matuyenxe);
            this.Controls.Add(this.label1);
            this.Name = "Themtuyen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm tuyến tàu xe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Themtuyen_FormClosing);
            this.Load += new System.EventHandler(this.Themtuyen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsSanPham)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_matuyenxe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_stt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_maga;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_stttramdung;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_gioghe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_giodi;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.DataGridView dsSanPham;
    }
}