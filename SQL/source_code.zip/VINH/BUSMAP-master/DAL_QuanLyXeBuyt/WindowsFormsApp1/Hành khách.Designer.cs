﻿namespace WindowsFormsApp1
{
    partial class Passenger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ViewDanhSach = new System.Windows.Forms.DataGridView();
            this.btn_Hanhkhach_Close = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewDanhSach)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(195, 117);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(439, 238);
            this.dataGridView1.TabIndex = 0;
            // 
            // ViewDanhSach
            // 
            this.ViewDanhSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ViewDanhSach.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.ViewDanhSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViewDanhSach.Location = new System.Drawing.Point(7, 12);
            this.ViewDanhSach.Name = "ViewDanhSach";
            this.ViewDanhSach.Size = new System.Drawing.Size(768, 361);
            this.ViewDanhSach.TabIndex = 1;
            // 
            // btn_Hanhkhach_Close
            // 
            this.btn_Hanhkhach_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Hanhkhach_Close.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Hanhkhach_Close.Location = new System.Drawing.Point(331, 379);
            this.btn_Hanhkhach_Close.Name = "btn_Hanhkhach_Close";
            this.btn_Hanhkhach_Close.Size = new System.Drawing.Size(109, 37);
            this.btn_Hanhkhach_Close.TabIndex = 2;
            this.btn_Hanhkhach_Close.Text = "Thoát";
            this.btn_Hanhkhach_Close.UseVisualStyleBackColor = true;
            this.btn_Hanhkhach_Close.Click += new System.EventHandler(this.btn_Hanhkhach_Close_Click);
            // 
            // Passenger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Hanhkhach_Close;
            this.ClientSize = new System.Drawing.Size(787, 426);
            this.Controls.Add(this.btn_Hanhkhach_Close);
            this.Controls.Add(this.ViewDanhSach);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Passenger";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hành khách";
            this.Load += new System.EventHandler(this.Passenger_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewDanhSach)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView ViewDanhSach;
        private System.Windows.Forms.Button btn_Hanhkhach_Close;
    }
}