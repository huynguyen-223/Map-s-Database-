﻿namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Logout = new System.Windows.Forms.Button();
            this.btn_ThemTuyenTauXe = new System.Windows.Forms.Button();
            this.btn_hanhkhach = new System.Windows.Forms.Button();
            this.btn_bangthongke = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Logout
            // 
            this.btn_Logout.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.Location = new System.Drawing.Point(278, 84);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(139, 36);
            this.btn_Logout.TabIndex = 4;
            this.btn_Logout.Text = "Đăng xuất";
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // btn_ThemTuyenTauXe
            // 
            this.btn_ThemTuyenTauXe.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThemTuyenTauXe.Location = new System.Drawing.Point(278, 32);
            this.btn_ThemTuyenTauXe.Name = "btn_ThemTuyenTauXe";
            this.btn_ThemTuyenTauXe.Size = new System.Drawing.Size(139, 35);
            this.btn_ThemTuyenTauXe.TabIndex = 2;
            this.btn_ThemTuyenTauXe.Text = "Thêm tuyến tàu xe";
            this.btn_ThemTuyenTauXe.UseVisualStyleBackColor = true;
            this.btn_ThemTuyenTauXe.Click += new System.EventHandler(this.btn_ThemTuyenTauXe_Click);
            // 
            // btn_hanhkhach
            // 
            this.btn_hanhkhach.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hanhkhach.Location = new System.Drawing.Point(39, 32);
            this.btn_hanhkhach.Name = "btn_hanhkhach";
            this.btn_hanhkhach.Size = new System.Drawing.Size(211, 35);
            this.btn_hanhkhach.TabIndex = 1;
            this.btn_hanhkhach.Text = "Thông tin hành khách";
            this.btn_hanhkhach.UseVisualStyleBackColor = true;
            this.btn_hanhkhach.Click += new System.EventHandler(this.btn_hanhkhach_Click);
            // 
            // btn_bangthongke
            // 
            this.btn_bangthongke.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bangthongke.Location = new System.Drawing.Point(39, 84);
            this.btn_bangthongke.Name = "btn_bangthongke";
            this.btn_bangthongke.Size = new System.Drawing.Size(211, 36);
            this.btn_bangthongke.TabIndex = 3;
            this.btn_bangthongke.Text = "Bảng thống kê lượt hành khách";
            this.btn_bangthongke.UseVisualStyleBackColor = true;
            this.btn_bangthongke.Click += new System.EventHandler(this.btn_bangthongke_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btn_Logout;
            this.ClientSize = new System.Drawing.Size(464, 157);
            this.Controls.Add(this.btn_bangthongke);
            this.Controls.Add(this.btn_hanhkhach);
            this.Controls.Add(this.btn_ThemTuyenTauXe);
            this.Controls.Add(this.btn_Logout);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang quản lý";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Button btn_ThemTuyenTauXe;
        private System.Windows.Forms.Button btn_hanhkhach;
        private System.Windows.Forms.Button btn_bangthongke;
    }
}